
module.exports.homeGet = (req, res)=>{
    res.redirect('/user/profile')
}
